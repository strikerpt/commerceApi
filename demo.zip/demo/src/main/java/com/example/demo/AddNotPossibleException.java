package com.example.demo;

public class AddNotPossibleException extends Exception{

}
